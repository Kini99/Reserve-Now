function PrivateRoute(){
    return(
        <div></div>
    )
}

export default PrivateRoute;
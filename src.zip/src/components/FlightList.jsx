import Flight from "./Flight"
import { useEffect } from "react";


function FlightList(){



    return(
        <>
        <Flight  />
        Pagination
        </>
    )
}
export default FlightList;
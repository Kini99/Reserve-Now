import NavBar from "../components/Navbar";

function Payment(){
    return(
        <NavBar />
    )
}

export default Payment;
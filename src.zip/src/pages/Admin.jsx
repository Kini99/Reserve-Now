import Dashboard from "../components/Dashboard";

function Admin() {
    return (
        <>
            < Dashboard/>
        </>
    )
}

export default Admin;

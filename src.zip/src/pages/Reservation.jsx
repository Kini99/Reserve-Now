import Header from "../components/Header";
import { useState } from "react";
import {Text, Heading, Input} from "@chakra-ui/react"

function Reservation() {
    const [step, setStep] = useState(1);
    const handleNextStep = () => {
        setStep(step + 1);
    };

    const searchInputs={
        type: "round",
  class: "economy",
  adults: 1,
  children: 0,
  from: "Delhi",
  to: "Goa",
  departDate: "03/04/2023",
    }

    return (
        <>
            <Header />
            <div className="slider">
                <div className={`step ${step >= 1 ? 'completed' : ''}`}>
                    <span>{step >= 1 ? <span>&#10003;</span> : '1'}</span>
                    <p>Select Flight</p>
                </div>
                <div className={`step ${step >= 2 ? 'completed' : ''}`}>
                    <span>{step >= 2 ? <span>&#10003;</span> : '2'}</span>
                    <p>Who's Flying</p>
                </div>
                <div className={`step ${step >= 3 ? 'completed' : ''}`}>
                    <span>{step >= 3 ? <span>&#10003;</span> : '3'}</span>
                    <p>Check and Pay</p>
                </div>
                
            </div>
<Text>One Way . {searchInputs.adults} traveller . {searchInputs.departDate}</Text>
<Heading as="h1" size="lg">{searchInputs.from} to {searchInputs.to}</Heading>
<Heading as="h2" size="md">Who's flying?</Heading>
<div style={{display:"flex"}}>
<div style={{border: "0.5px solid #ededed"}}>
<Heading as="h3" size="sm">Contact Details</Heading>
<p><span style={{color:"red"}}>*</span> Required</p>
<Text>Contact Email <span style={{color:"red"}}>*</span></Text>
<Input></Input>
<p>We'll send your flight confirmation here</p>
</div>
<div></div>
</div>




            {/* <div className="button-container">
                    {step < 3 ? (
                        <button onClick={handleNextStep}>Next</button>
                    ) : (
                        <button>Finish</button>
                    )}
                </div> */}
        </>

    )
}

export default Reservation;
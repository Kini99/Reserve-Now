function UnderConstruction(){
    return (
        <>
        <img src="https://static.wixstatic.com/media/38bdd6_833119a5283c44d7a154a745356c5244~mv2.gif" alt="" style={{width:"100%", marginTop:"-10%"}} />
        </>
    )
}
export default UnderConstruction;
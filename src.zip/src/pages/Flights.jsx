import NavBar from "../components/Navbar";

function Flights(){
    return(
        <>
        <NavBar />
        <Flight />
        Pagination
        </>
    )
}

export default Flights;